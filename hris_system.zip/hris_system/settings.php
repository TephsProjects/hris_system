<?php
session_start();
include('includes/db.php');

// Access check
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch system settings (assuming only one row)
$stmt = $conn->prepare("SELECT * FROM settings LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();

// Insert default row if none exists
if ($result->num_rows === 0) {
    $conn->query("INSERT INTO settings (default_work_hours, regularization_days, date_format, notify_new_employee, notify_leave_request) VALUES ('8:00-17:00', 90, 'Y-m-d', 1, 1)");
    $stmt->execute();
    $result = $stmt->get_result();
}

$settings = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Settings</title>
    <link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <style>
        .main-content {
            padding: 40px 20px;
            display: flex;
            justify-content: center;
        }

        .info-section {
            background: #fff;
            border-radius: 12px;
            padding: 35px 40px;
            max-width: 700px;
            width: 100%;
            box-shadow: 0 6px 18px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }

        .info-section:hover {
            transform: translateY(-3px);
        }

        .info-section h3 {
            text-align: center;
            font-size: 1.7rem;
            color: #333;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .form-row {
            margin-bottom: 18px;
        }

        .form-row label {
            font-weight: 600;
            display: block;
            margin-bottom: 6px;
            color: #555;
        }

        .form-control {
            width: 95%;
            padding: 11px 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
            transition: 0.2s;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
            outline: none;
        }

        .update-btn {
            display: block;
            width: 100%;
            padding: 12px 0;
            font-size: 1rem;
            font-weight: 600;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 25px;
            transition: background 0.2s;
        }

        .update-btn:hover {
            background-color: #0056b3;
        }

        .message-success {
            background: #d4edda;
            color: #155724;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= htmlspecialchars($_SESSION['full_name']); ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<nav class="sub-navbar">
    <ul class="nav-menu">
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)" class="active">Info ▾</a>
            <ul class="dropdown-content">
                <li><a href="company_info.php">Company Information</a></li>
                <li><a href="settings.php" class="active">Settings</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Job Opening</a></li>
                <li><a href="job_list.php">Job List</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_branch.php">Add Branch / Location</a></li>
                <li><a href="branch_list.php">Branch / Location List</a></li>
                <li><a href="add_position.php">Add Position</a></li>
                <li><a href="position_list.php">Position List</a></li>
                <li><a href="add_department.php">Add Department</a></li>
                <li><a href="department_list.php">Department List</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_performance.php">Add Evaluation</a></li>
                    <li><a href="performance_list.php">Evaluations</a></li>
                </ul>
            </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
    </ul>
</nav>

<div class="main-content">
    <div class="info-section">
        <?php if (isset($_GET['updated'])): ?>
            <div class="message-success">✅ Settings updated successfully!</div>
        <?php endif; ?>

        <h3>System Settings</h3>
        <form method="POST" action="update_settings.php">
            <input type="hidden" name="id" value="<?= $settings['id'] ?? '' ?>">

            <div class="form-row">
                <label>Default Work Hours:</label>
                <input type="text" name="default_work_hours" class="form-control" value="<?= htmlspecialchars($settings['default_work_hours'] ?? '8:00-17:00') ?>" required>
            </div>

            <div class="form-row">
                <label>Regularization Period (Days):</label>
                <input type="number" name="regularization_days" class="form-control" value="<?= htmlspecialchars($settings['regularization_days'] ?? 90) ?>" required>
            </div>

            <div class="form-row">
                <label>Date Format:</label>
                <input type="text" name="date_format" class="form-control" value="<?= htmlspecialchars($settings['date_format'] ?? 'Y-m-d') ?>" required>
            </div>

            <div class="form-row">
                <label>Notify on New Employee:</label>
                <select name="notify_new_employee" class="form-control">
                    <option value="1" <?= ($settings['notify_new_employee'] ?? 1) ? 'selected' : '' ?>>Yes</option>
                    <option value="0" <?= !($settings['notify_new_employee'] ?? 1) ? 'selected' : '' ?>>No</option>
                </select>
            </div>

            <div class="form-row">
                <label>Notify on Leave Request:</label>
                <select name="notify_leave_request" class="form-control">
                    <option value="1" <?= ($settings['notify_leave_request'] ?? 1) ? 'selected' : '' ?>>Yes</option>
                    <option value="0" <?= !($settings['notify_leave_request'] ?? 1) ? 'selected' : '' ?>>No</option>
                </select>
            </div>

            <button type="submit" class="update-btn">💾 Update Settings</button>
        </form>
    </div>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();
    document.querySelectorAll('.dropdown').forEach(d => {
        if (!d.contains(event.target)) d.classList.remove('active');
    });
    event.target.closest('.dropdown').classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e){ e.preventDefault(); logoutModal.style.display='block'; }
closeModal.onclick = function(){ logoutModal.style.display='none'; }
cancelLogout.onclick = function(){ logoutModal.style.display='none'; }
confirmLogout.onclick = function(){ window.location.href='logout.php'; }
window.onclick = function(event){ if(event.target==logoutModal){ logoutModal.style.display='none'; } }
</script>
</body>
</html>

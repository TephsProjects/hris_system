<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$where = "";
if (isset($_GET['job_id']) && is_numeric($_GET['job_id'])) {
    $job_id = $_GET['job_id'];
    $where = "WHERE c.job_id = $job_id";
}

$sql = "SELECT c.*, j.title AS job_title 
        FROM candidates c 
        LEFT JOIN job_openings j ON c.job_id = j.job_id
        $where
        ORDER BY c.applied_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Candidates</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<style>
    tr:nth-child(even) {
        background-color: #f8f9fa;
    }

    tr:hover {
        background-color: #e9f5ff;
    }

    .status-select {
        padding: 5px 8px;
        border-radius: 6px;
        border: 1px solid #ccc;
        background: #fff;
        font-weight: bold;
    }

    .status-applied {
        background-color: #f0f0f0;
        color: #555;
    }

    .status-screened {
        background-color: #d1ecf1;
        color: #0c5460;
    }

    .status-interview {
        background-color: #fff3cd;
        color: #856404;
    }

    .status-hired {
        background-color: #d4edda;
        color: #155724;
    }

    .status-rejected {
        background-color: #f8d7da;
        color: #721c24;
    }

    .status-select:focus {
        outline: none;
        border-color: #007bff;
    }

    #statusMsg {
        margin: 10px 0;
        padding: 10px;
        font-weight: bold;
        display: none;
        border-radius: 5px;
    }

    #statusMsg.success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    #statusMsg.error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
</style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?php echo $_SESSION['full_name']; ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<div class="sub-navbar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Requests</a></li>
            </ul>
        </li>

        <!-- <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Payroll ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_payroll.php">Add Payroll</a></li>
                <li><a href="payroll.php">Payroll List</a></li>
                <li><a href="add_benefits.php">Add Benefits</a></li>
                <li><a href="benefits_list.php">Benefits List</a></li>
            </ul>
        </li> -->

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job Opening</a></li>
                <li><a href="job_list.php">Job Openings</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php" class="active">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluations</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
    </ul>
</div>

<div class="main-content">
    <h3>Candidates List</h3>
    <div id="statusMsg"></div>

    <table>
        <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Job Title</th>
            <th>Status</th>
            <th>Resume</th>
            <th>Applied At</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['job_title']) ?></td>
            <td>
                <select class="status-select" 
                        onchange="updateStatus(<?= $row['candidate_id'] ?>, this.value); setStatusColor(this);" 
                        id="status-<?= $row['candidate_id'] ?>">
                    <option value="Applied"   <?= $row['status'] == 'Applied' ? 'selected' : '' ?>>Applied</option>
                    <option value="Screened"  <?= $row['status'] == 'Screened' ? 'selected' : '' ?>>Screened</option>
                    <option value="Interview" <?= $row['status'] == 'Interview' ? 'selected' : '' ?>>Interview</option>
                    <option value="Hired"     <?= $row['status'] == 'Hired' ? 'selected' : '' ?>>Hired</option>
                    <option value="Rejected"  <?= $row['status'] == 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>
            </td>
            <td>
                <?php if ($row['resume']): ?>
                    <a href="uploads/resumes/<?= htmlspecialchars($row['resume']) ?>" target="_blank">View</a>
                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['applied_at']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function toggleDropdown(event) {
    event.preventDefault();
    document.querySelectorAll('.dropdown').forEach(drop => {
        if (!drop.contains(event.target)) drop.classList.remove('active');
    });
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

function setStatusColor(select) {
    select.classList.remove(
        'status-applied',
        'status-screened',
        'status-interview',
        'status-hired',
        'status-rejected'
    );

    const value = select.value.toLowerCase();
    select.classList.add('status-' + value);
}

function updateStatus(candidateId, newStatus) {
    fetch('update_candidate_status.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'candidate_id=' + candidateId + '&status=' + encodeURIComponent(newStatus)
    })
    .then(response => response.text())
    .then(data => {
        const msg = document.getElementById('statusMsg');
        msg.style.display = 'block';
        if (data.startsWith('success')) {
            msg.className = 'success';
            msg.textContent = 'Candidate status updated successfully.';

            if (newStatus === 'Hired' && data.includes('|')) {
                const empId = data.split('|')[1];
                setTimeout(() => {
                    window.location.href = 'edit_employee.php?emp_id=' + empId;
                }, 1000);
            }
        } else {
            msg.className = 'error';
            msg.textContent = 'Error updating candidate status.';
        }
        setTimeout(() => msg.style.display = 'none', 2500);
    })
    .catch(err => {
        console.error(err);
    });
}

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.status-select').forEach(setStatusColor);
});

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}

closeModal.onclick = function() {
    logoutModal.style.display = 'none';
}

cancelLogout.onclick = function() {
    logoutModal.style.display = 'none';
}

confirmLogout.onclick = function() {
    window.location.href = 'logout.php';
}

window.onclick = function(event) {
    if (event.target == logoutModal) {
        logoutModal.style.display = 'none';
    }
}
</script>
</body>
</html>
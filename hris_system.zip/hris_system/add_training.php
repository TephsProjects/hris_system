<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$employees = $conn->query("SELECT emp_id, CONCAT(first_name, ' ', last_name) AS name FROM employees ORDER BY name ASC");

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_employees = isset($_POST['emp_ids']) ? $_POST['emp_ids'] : [];
    $title = trim($_POST['title']);
    $progress = isset($_POST['progress']) ? intval($_POST['progress']) : 0;
    $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

    if (!empty($selected_employees) && !empty($title)) {
        $stmt = $conn->prepare("INSERT INTO trainings (emp_id, title, progress, due_date) VALUES (?, ?, ?, ?)");
        foreach ($selected_employees as $emp_id) {
            $emp_id = intval($emp_id);
            $stmt->bind_param("isis", $emp_id, $title, $progress, $due_date);
            $stmt->execute();
        }
        $message = "✅ Training assigned successfully to selected employees!";
    } else {
        $message = "⚠️ Please fill in all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Training</title>
<link rel="icon" type="image/png" href="assets/images/PulseWork-logo.png">
<link rel="stylesheet" href="assets/css/style.css">
<style>
/* ---------- Form Container ---------- */
.form-container {
    background: #fff;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
    max-width: 720px;
    margin: 20px auto;
}

/* ---------- Labels & Inputs ---------- */
label {
    display: block;
    margin-top: 15px;
    font-weight: 600;
}

input[type="text"], input[type="date"], input[type="number"] {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border-radius: 8px;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* ---------- Employee Search Box ---------- */
.employee-search-container {
    margin-bottom: 8px;
}

.employee-search-container input {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

/* ---------- Employee Checkbox List ---------- */
.employee-checkbox-list {
    max-height: 180px;
    overflow-y: auto;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 6px;
    background: #fafafa;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.employee-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 4px 6px;
    cursor: pointer;
    font-size: 14px;
}

.employee-item input[type="checkbox"] {
    flex-shrink: 0;
}

.employee-item .employee-name {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.employee-item:hover {
    background: #f1f1f1;
    border-radius: 6px;
}

/* ---------- Button ---------- */
button {
    margin-top: 20px;
    padding: 10px 20px;
    background: #007bff;
    border: none;
    color: #fff;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: background 0.3s ease;
}

button:hover {
    background: #0056b3;
}

/* ---------- Message ---------- */
.message {
    margin-bottom: 15px;
    padding: 10px 15px;
    border-radius: 8px;
    font-weight: 600;
}

.message.success {
    background: #d4edda;
    color: #155724;
}

.message.error {
    background: #f8d7da;
    color: #721c24;
}
</style>
</head>
<body>
<div class="navbar">
    <h2>PulseWork: HR Information System</h2>
    <div class="user-info">
        <span>Welcome, <?= $_SESSION['full_name']; ?></span>
        <a href="#" class="logout-btn" id="logoutBtn">Logout</a>
    </div>
</div>

<div class="sub-navbar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Info ▾</a>
                <ul class="dropdown-content">
                    <li><a href="company_info.php">Company Information</a></li>
                    <li><a href="settings.php">Settings</a></li>
                </ul>
            </li>
            
        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Leave ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_leave.php">Leave Form</a></li>
                <li><a href="leave_requests.php">Leave Request Lists</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Reports & Accounts ▾</a>
            <ul class="dropdown-content">
                <li><a href="reports.php">Reports</a></li>
                <li><a href="accounts.php">Accounts</a></li>
                <li><a href="add_employee.php">Add Employee</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Recruitment ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_job.php">Add Job Opening</a></li>
                <li><a href="job_list.php">Job Openings</a></li>
                <li><a href="add_candidate.php">Add Candidate</a></li>
                <li><a href="candidate_list.php">Candidates</a></li>
            </ul>
        </li>

        <li class="dropdown">
            <a href="#" class="active" onclick="toggleDropdown(event)">Onboarding and Training ▾</a>
            <ul class="dropdown-content">
                <li><a href="onboarding_list.php">Onboarding Tasks</a></li>
                <li><a href="add_onboarding.php">Add Onboarding Task</a></li>
                <li><a href="training_list.php">Trainings</a></li>
                <li><a href="add_training.php" class="active">Add Training</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Branch / Position / Departments ▾</a>
                <ul class="dropdown-content">
                    <li><a href="add_branch.php">Add Branch / Location</a></li>
                    <li><a href="branch_list.php">Branch / Location List</a></li>
                    <li><a href="add_position.php">Add Position</a></li>
                    <li><a href="position_list.php">Position List</a></li>
                    <li><a href="add_department.php">Add Department</a></li>
                    <li><a href="department_list.php">Department List</a></li>
                </ul>
            </li>

        <li class="dropdown">
            <a href="#" onclick="toggleDropdown(event)">Performance ▾</a>
            <ul class="dropdown-content">
                <li><a href="add_performance.php">Add Evaluation</a></li>
                <li><a href="performance_list.php">Evaluation List</a></li>
            </ul>
        </li>

        <li class="dropdown">
                <a href="#" onclick="toggleDropdown(event)">Documents ▾</a>
                <ul class="dropdown-content">
                    <li><a href="sss_r1a_form.php">SSS Form R1-A</a></li>
                    <li><a href="philhealth_er2_form.php">Philhealth Form Er2</a></li>
                    <li><a href="assets/pdfs/pmrf_012020.pdf" target="_blank">Philhealth Member Registration Form</a></li>
                    <li><a href="assets/pdfs/1902 October 2025 (ENCS) Final.pdf" target="_blank">BIR - Application for Registration(1902)</a></li>
                    <li><a href="assets/pdfs/BIR-FORM-2305.pdf" target="_blank">BIR - Certificate of Update of Exemption(2305)</a></li>
                </ul>
            </li>
    </ul>
</div>

<div class="main-content">
    <h3>Add Training</h3>
    <div class="form-container">

        <?php if ($message): ?>
            <div class="message <?= strpos($message, '✅') !== false ? 'success' : 'error' ?>">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <!-- Employee Search Box -->
            <label>Select Employees:</label>
            <div class="employee-search-container">
                <input type="text" id="employeeSearch" placeholder="Search employee..." onkeyup="filterEmployees()">
            </div>

            <!-- Employee Checkbox List -->
            <div class="employee-checkbox-list">
                <?php $employees->data_seek(0); // reset pointer ?>
                <?php while ($emp = $employees->fetch_assoc()): ?>
                    <label class="employee-item">
                        <input type="checkbox" name="emp_ids[]" value="<?= $emp['emp_id']; ?>">
                        <span class="employee-name"><?= htmlspecialchars($emp['name']); ?></span>
                    </label>
                <?php endwhile; ?>
            </div>
            <small style="color:gray;">You can select multiple employees</small>

            <label>Training Title:</label>
            <input type="text" name="title" placeholder="e.g., Workplace Safety & Compliance" required>

            <label>Due Date:</label>
            <input type="date" name="due_date" required>

            <label>Initial Progress (%):</label>
            <input type="number" name="progress" min="0" max="100" value="0">

            <button type="submit">Add Training</button>
        </form>
    </div>
</div>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Confirm Logout</h3>
        <p>Are you sure you want to logout?</p>
        <div class="modal-buttons">
            <button id="confirmLogout" class="btn">Yes, Logout</button>
            <button id="cancelLogout" class="btn" style="background:#ccc;color:#333;">Cancel</button>
        </div>
    </div>
</div>

<script>
function filterEmployees() {
    const input = document.getElementById('employeeSearch').value.toLowerCase();
    const items = document.querySelectorAll('.employee-item');
    items.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(input) ? '' : 'none';
    });
}

function toggleDropdown(event) {
    event.preventDefault();
    const parent = event.target.closest('.dropdown');
    parent.classList.toggle('active');
}

const logoutBtn = document.getElementById('logoutBtn');
const logoutModal = document.getElementById('logoutModal');
const closeModal = document.querySelector('.close');
const cancelLogout = document.getElementById('cancelLogout');
const confirmLogout = document.getElementById('confirmLogout');

logoutBtn.onclick = function(e) {
    e.preventDefault();
    logoutModal.style.display = 'block';
}
closeModal.onclick = function() { logoutModal.style.display = 'none'; }
cancelLogout.onclick = function() { logoutModal.style.display = 'none'; }
confirmLogout.onclick = function() { window.location.href = 'logout.php'; }
window.onclick = function(event) {
    if (event.target == logoutModal) logoutModal.style.display = 'none';
}
</script>
</body>
</html>
